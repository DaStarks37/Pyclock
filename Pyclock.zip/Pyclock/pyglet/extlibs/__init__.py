"""
External dependencies for Pyglet.

These dependencies are included to publish Pyglet as a fully self-contained package.
"""
