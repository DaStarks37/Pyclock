import tkinter as tk
from tkinter import PhotoImage
import datetime as dt
import pyglet

#Creating vars
colorprimary = "#1f1f1f"
coloraccent = "#21d900"
darkmodestatus = True
onclock = 0
onalarm = 0
ontimer = 0

#Creating main application window
root = tk.Tk()
root.configure(bg=colorprimary)
root.resizable(False, False)
root.geometry("550x250")
#Add a cool digital clock font
pyglet.font.add_directory('fonts')
#Image path for Dark/Light mode button
bulbimage = PhotoImage(file="imgs\lightbulbgreen.png")

#Real time digital clock.
def updateclockdisplay(clockdisplay):
    #Added .strftime to get rid of those ugly milliseconds or microseconds or whatever the hell
    currentdatetime = dt.datetime.now().strftime("%H:%M:%S")
    clockdisplay.config(text=currentdatetime)
    clockdisplay.after(1000, updateclockdisplay, clockdisplay)

#You can use this to clear the screen when changing between Clock, Alarm, and Timer, whilst keeping the buttons!
def clear_all_but(whattokeep):
    for child in root.winfo_children():
        if child != whattokeep:
            child.destroy()

def makeclockscreen():
    global darkmodestatus, colorprimary, coloraccent, bulbimage, clockdisplay, onclock
    if onclock <= 0:
        # Create clock display label        
        onclock = 1
        clockdisplay = tk.Label(root, font=('DS-Digital Bold', 80), fg=coloraccent, bg=colorprimary)
        clockdisplay.pack(anchor="center",pady=25)
        updateclockdisplay(clockdisplay)
    else:
        pass

#Finish these
def makealarmscreen():
    clear_all_but(button_frame)
    global onclock,onalarm,ontimer
    onclock = 0
    ontimer = 0
    pass
def maketimerscreen():
    clear_all_but(button_frame)
    pass

#Everyone loves the option to switch from light and dark mode.
def dark_mode():
    global darkmodestatus, colorprimary, coloraccent, bulbimage, buttonstyle
    if darkmodestatus == 1:
        colorprimary = "#f7f7f0"
        coloraccent = "#000000"
        bulbimage = PhotoImage(file="imgs\lightbulb.png")
        buttonstyle.update({
            "bg": colorprimary,
            "fg": coloraccent,
            "highlightbackground": colorprimary,
            "highlightcolor": colorprimary,
            "activebackground": coloraccent,
            "activeforeground": colorprimary
        })
        update_colors()
        darkmodestatus = False
    else:
        colorprimary = "#1f1f1f"
        coloraccent = "#21d900"
        bulbimage = PhotoImage(file="imgs\lightbulbgreen.png")
        buttonstyle.update({
            "bg": colorprimary,
            "fg": coloraccent,
            "highlightbackground": colorprimary,
            "highlightcolor": colorprimary,
            "activebackground": coloraccent,
            "activeforeground": colorprimary
        })
        update_colors()
        darkmodestatus = True

def update_colors():
    root.config(bg=colorprimary)
    clockdisplay.config(fg=coloraccent, bg=colorprimary)
    button_frame.config(bg=colorprimary)
    dark_mode_button.config(image=bulbimage)
    clock_button.config(**buttonstyle)
    alarms_button.config(**buttonstyle)
    timer_button.config(**buttonstyle)
    dark_mode_button.config(**buttonstyle)

buttonstyle = {
    "bg": colorprimary,      # black background
    "fg": coloraccent,      # green text
    "bd": 1,            # border width
    "relief": "flat",   # flat border style
    "highlightbackground": colorprimary, # highlightbackground and highlightcolor for the border color
    "highlightcolor": colorprimary,
    "activebackground": coloraccent,  # black background when button is pressed
    "activeforeground": colorprimary   # black text when button is pressed
}

# Create a frame to hold the buttons
def createbuttons():
    global button_frame, dark_mode_button, clock_button, alarms_button, timer_button
    button_frame = tk.Frame(root,bg=colorprimary)
    button_frame.pack(side="top")
    # Create the buttons
    clock_button = tk.Button(button_frame,text="Clock",command=makeclockscreen,**buttonstyle)
    clock_button.pack(side="left", padx=5, pady=5)
    alarms_button = tk.Button(button_frame, text="Alarms", command=makealarmscreen,**buttonstyle)
    alarms_button.pack(side="left", padx=5, pady=5)
    timer_button = tk.Button(button_frame, text="Timer", command=maketimerscreen,**buttonstyle)
    timer_button.pack(side="left", padx=5, pady=5)
    dark_mode_button = tk.Button(button_frame, image=bulbimage, command=dark_mode,**buttonstyle)
    dark_mode_button.pack(side="left", padx=5, pady=5)

createbuttons()
makeclockscreen()
root.mainloop()
