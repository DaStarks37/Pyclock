from playsound import playsound
import tkinter as tk
from tkinter import PhotoImage, simpledialog
import datetime as dt
import pyglet

#Creating vars
colorprimary = "#1f1f1f"
coloraccent = "#21d900"
darkmodestatus = True
onclock = 0
onalarm = 0
ontimer = 0
alarms = []
timer_running = False
timer_start_time = None
timer_display_label = None


#Creating main application window
root = tk.Tk()
root.configure(bg=colorprimary)
root.resizable(False, False)
root.geometry("550x250")
#Add a cool digital clock font
pyglet.font.add_directory('fonts')
#Image path for Dark/Light mode button
bulbimage = PhotoImage(file="imgs/ightbulbgreen.png")


#Real time digital clock.
def updateclockdisplay(clockdisplay):
    #Added .strftime to get rid of those ugly milliseconds or microseconds or whatever the hell
    currentdatetime = dt.datetime.now().strftime("%H:%M:%S")
    clockdisplay.config(text=currentdatetime)
    clockdisplay.after(1000, updateclockdisplay, clockdisplay)

#You can use this to clear the screen when changing between Clock, Alarm, and Timer, whilst keeping the buttons!
def clear_all_but(whattokeep):
    for child in root.winfo_children():
        if child != whattokeep:
            child.pack_forget()

#The clock screen
def makeclockscreen():
    global darkmodestatus, colorprimary, coloraccent, bulbimage, clockdisplay, onclock, onalarm, ontimer
    if onclock <= 0:
        onalarm = 0
        ontimer = 0
        clear_all_but(button_frame)
        # Create clock display label        
        onclock = 1
        clockdisplay = tk.Label(root, font=('DS-Digital Bold', 80), fg=coloraccent, bg=colorprimary)
        clockdisplay.pack(anchor="center",pady=25)
        updateclockdisplay(clockdisplay)
        update_colors()
    else:
        print("You're already on the clock!")

# Alarm Screen
def makealarmscreen():
    clear_all_but(button_frame)
    global onclock, onalarm, ontimer, canvas, scrollable_frame, alarms
    onclock = 0
    ontimer = 0
    onalarm = 1
    
    canvas = tk.Canvas(root, bg="#1f1f1f", highlightthickness=0, width=150)
    scrollable_frame = tk.Frame(canvas, bg="#1f1f1f")
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left")
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    
    def update_scroll_region(event):
        canvas.configure(scrollregion=canvas.bbox("all"))
        
    scrollable_frame.bind("<Configure>", update_scroll_region)

    def refresh_alarms():
        for widget in scrollable_frame.winfo_children():
            widget.destroy()
        for index, (time, enabled) in enumerate(alarms):
            alarm_text = f"{time} - {'Enabled' if enabled else 'Disabled'}"
            timelabel = tk.Label(scrollable_frame, text=alarm_text, fg=coloraccent, bg=colorprimary)
            timelabel.pack()
            toggle_button = tk.Button(scrollable_frame, text="Toggle", command=lambda idx=index: toggle_alarm(idx))
            toggle_button.pack()
            delete_button = tk.Button(scrollable_frame, text="Delete", command=lambda idx=index: delete_alarm(idx))
            delete_button.pack()

    def toggle_alarm(index):
        time, enabled = alarms[index]
        alarms[index] = (time, not enabled)
        refresh_alarms()

    def delete_alarm(index):
        del alarms[index]
        refresh_alarms()

    def add_alarm():
        time = simpledialog.askstring("Add New Alarm", "Enter time (HH:MM):")
        alarms.append((time, True))
        refresh_alarms()

    add_button = tk.Button(root, text="Add Alarm", command=add_alarm)
    add_button.pack(side="bottom", pady=5)
    
    refresh_alarms()

    clockdisplay.pack(pady=35)
    check_alarms()

# Functions to check for alarms and trigger sound playback
def play_alarm():
    playsound('alarm.wav', block=False)

def check_alarms():
    current_time = dt.datetime.now().strftime("%H:%M")
    for time, enabled in alarms:
        if time == current_time and enabled == True:
            print(f"Alarm at {time} triggered!")
            play_alarm()
    root.after(1000, check_alarms)

# Timer screen
def maketimerscreen():
    global ontimer, onclock, onalarm, timer_running, timer_start_time, timer_display_label, start_stop_button, reset_button
    clear_all_but(button_frame)
    onclock = 0
    onalarm = 0
    ontimer = 1
    timer_running = False
    
    # Timer display
    timer_display_label = tk.Label(root, font=('DS-Digital Bold', 50), fg=coloraccent, bg=colorprimary, text="00:00:00")
    timer_display_label.pack(anchor="center", pady=20)
    
    # Start/Stop Button
    start_stop_button = tk.Button(root, text="Start", command=toggle_timer, **buttonstyle)
    start_stop_button.pack(side="left", padx=10)
    
    # Reset Button
    reset_button = tk.Button(root, text="Reset", command=reset_timer, **buttonstyle)
    reset_button.pack(side="right", padx=10)

def toggle_timer():
    global timer_running, timer_start_time, start_stop_button
    if timer_running:
        timer_running = False
        start_stop_button.config(text="Start")
    else:
        timer_running = True
        start_stop_button.config(text="Pause")
        if timer_start_time is None:
            timer_start_time = dt.datetime.now()
        else:
            paused_duration = dt.datetime.now() - timer_last_stop_time
            timer_start_time += paused_duration
        update_timer()

def reset_timer():
    global timer_start_time, timer_running, timer_last_stop_time, start_stop_button
    timer_running = False
    timer_start_time = None
    timer_display_label.config(text="00:00:00")
    start_stop_button.config(text="Start")
# Adjust to track when the timer was last stopped to calculate pause duration
timer_last_stop_time = None

# Modify toggle_timer to update 'timer_last_stop_time' upon pausing
def toggle_timer():
    global timer_running, timer_start_time, timer_last_stop_time, start_stop_button
    if timer_running:
        timer_running = False
        timer_last_stop_time = dt.datetime.now()  # Record the time when the timer is paused
        start_stop_button.config(text="Start")
    else:
        timer_running = True
        if timer_start_time is None:
            timer_start_time = dt.datetime.now()
        elif timer_last_stop_time:
            # Adjust start time by paused duration to keep timer accurate
            paused_duration = dt.datetime.now() - timer_last_stop_time
            timer_start_time += paused_duration
        start_stop_button.config(text="Pause")
        update_timer()

def update_timer():
    global timer_start_time, timer_running
    if timer_running:
        elapsed_time = dt.datetime.now() - timer_start_time
        hours, remainder = divmod(elapsed_time.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        timer_display_label.config(text=f"{hours:02d}:{minutes:02d}:{seconds:02d}")
        root.after(1000, update_timer)

# Dark mode button
def dark_mode():
    global darkmodestatus, colorprimary, coloraccent, bulbimage, buttonstyle
    if darkmodestatus == 1:
        colorprimary = "#f7f7f0"
        coloraccent = "#000000"
        bulbimage = PhotoImage(file="imgs/ightbulb.png")
        buttonstyle.update({
            "bg": colorprimary,
            "fg": coloraccent,
            "highlightbackground": colorprimary,
            "highlightcolor": colorprimary,
            "activebackground": coloraccent,
            "activeforeground": colorprimary
        })
        update_colors()
        darkmodestatus = False
    else:
        colorprimary = "#1f1f1f"
        coloraccent = "#21d900"
        bulbimage = PhotoImage(file="imgs/ightbulbgreen.png")
        buttonstyle.update({
            "bg": colorprimary,
            "fg": coloraccent,
            "highlightbackground": colorprimary,
            "highlightcolor": colorprimary,
            "activebackground": coloraccent,
            "activeforeground": colorprimary
        })
        update_colors()
        darkmodestatus = True

def update_colors():
    global timer_display_label, start_stop_button, reset_button
    
    try:
        root.config(bg=colorprimary)
        
        if 'clockdisplay' in globals():  # Check if clockdisplay exists
            clockdisplay.config(fg=coloraccent, bg=colorprimary)
            
        if 'canvas' in globals() and 'scrollable_frame' in globals():
            canvas.config(bg=colorprimary)
            scrollable_frame.config(bg=colorprimary)
            
        if 'timer_display_label' in globals(): 
            timer_display_label.config(fg=coloraccent, bg=colorprimary)
            
        if 'start_stop_button' in globals():
            start_stop_button.config(bg=colorprimary, fg=coloraccent, activebackground=coloraccent, activeforeground=colorprimary)
            
        if 'reset_button' in globals(): 
            reset_button.config(bg=colorprimary, fg=coloraccent, activebackground=coloraccent, activeforeground=colorprimary)
            
        # Update other elements like buttons
        button_frame.config(bg=colorprimary)
        dark_mode_button.config(image=bulbimage)
        
        for button in [clock_button, alarms_button, timer_button, dark_mode_button]:
            button.config(**buttonstyle)

    except:
        pass


buttonstyle = {
    "bg": colorprimary,      # black background
    "fg": coloraccent,      # green text
    "bd": 1,            # border width
    "relief": "flat",   # flat border style
    "highlightbackground": colorprimary, # highlightbackground and highlightcolor for the border color
    "highlightcolor": colorprimary,
    "activebackground": coloraccent,  # black background when button is pressed
    "activeforeground": colorprimary   # black text when button is pressed
}

# Create a frame to hold the buttons
def createbuttons():
    global button_frame, dark_mode_button, clock_button, alarms_button, timer_button
    button_frame = tk.Frame(root,bg=colorprimary)
    button_frame.pack(side="top")
    # Create the buttons
    clock_button = tk.Button(button_frame,text="Clock",command=makeclockscreen,**buttonstyle)
    clock_button.pack(side="left", padx=5, pady=5)
    alarms_button = tk.Button(button_frame, text="Alarms", command=makealarmscreen,**buttonstyle)
    alarms_button.pack(side="left", padx=5, pady=5)
    timer_button = tk.Button(button_frame, text="Timer", command=maketimerscreen,**buttonstyle)
    timer_button.pack(side="left", padx=5, pady=5)
    dark_mode_button = tk.Button(button_frame, image=bulbimage, command=dark_mode,**buttonstyle)
    dark_mode_button.pack(side="left", padx=5, pady=5)

createbuttons()
makeclockscreen()
makealarmscreen()
maketimerscreen()
makeclockscreen()
root.mainloop()
